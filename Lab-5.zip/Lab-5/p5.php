<!-- Create a php page which takes the student’s name and marks of three subjects from
the user. It stores all information as cookies and displays all information on the next
page -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>p5</title>
    <style>
    input {
        width: 100%;
    }
    </style>
</head>

<body>
    <form method="POST" name="frm">
        <table>
            <tr>
                <th>Form</th>
            </tr>
            <tr>
                <td><input type="text" placeholder="Enter name" name="fname" required></td>
            </tr>
            <tr>
                <td><input type="number" placeholder="Enter 1st subject mark" name="m1" max="100" min="0" required></td>
            </tr>
            <tr>
                <td><input type="number" placeholder="Enter 2nd subject mark" name="m2" max="100" min="0" required></td>
            </tr>
            <tr>
                <td><input type="number" placeholder="Enter 3rd subject mark" name="m3" max="100" min="0" required></td>
            </tr>
            <tr>
                <td><input type="Submit" name="sbt" value="Submit"></td>
            </tr>
        </table>
    </form>
</body>
</html>
<?php
extract($_REQUEST); 
if(isset($sbt))
{
    setcookie("fname", $fname);
    //$_COOKIE['fname'] = $fname; 
    setcookie("m1", $m1); 
    setcookie("m2", $m2); 
    setcookie("m3", $m3);
}
?>