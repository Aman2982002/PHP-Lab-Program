<!-- Use HTML form created in practical -1 . Enter respective data into each and using the
post method pass the data and display the data to the data.php page on click on
submit button.
 -->
<?php
extract($_POST);
if(isset($sbt))
{
    echo("<h2>"); 
    echo("Name is $name . <br>"); 
    echo("Password is : " . $pass . "<br>"); 
    echo("Contact is : " . $contact . "<br>"); 
    echo("Branch is : " . $branch . "<br>"); 
    echo("</h2>");
}
?>