<!-- Create an HTML form which takes 10 numbers (comma separated) and redirect
control to findsum.php create a php script which stores the numbers into an
array and displays the total of the array -->
<?php
extract($_REQUEST);
if(isset($sbt))
{
    $arr = explode(" ", $no); 
    echo("No is : <br>"); 
    $result = array_sum($arr);
    foreach($arr as $ele)
    {
        echo($ele . "<br>");
    }  
    echo("<br>Sum is : $result<br>");
}
?> 