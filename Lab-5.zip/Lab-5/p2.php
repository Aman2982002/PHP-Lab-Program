<!--  Create a HTML form that reads 2 numbers and has 4 buttons for operation:- Add,
Difference, Product. Based on the button clicked by the user the result should be
displayed as output. -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calc</title>
    <style>
    input {
        width: 100%;
    }
    </style>
</head>
<body>
    <form method="POST" name="frm">
        <table>
            <tr>
                <th>Calculator</th>
            </tr>
            <tr>
                <td>
<?php
extract($_REQUEST);
if(isset($sbt))
{
    switch($sbt)
    {
    case "+":
        echo("Result is : " . ($no1 + $no2));
        break;
    case "-":
        echo("Result is : " . ($no1 - $no2));
        break;
    case "*":
        echo("Result is : " . ($no1 * $no2));
        break;
    case "/":
        echo("Result is : " . ($no1 / $no2));
        break;
    }
}
?>
                </td>
            </tr>
            <tr>
                <td><input type="number" placeholder="Enter 1st no" name="no1" min="0" required></td>
            </tr>
            <tr>
                <td><input type="number" placeholder="Enter 2nd no" name="no2" min="0" required></td>
            </tr>
            <tr>
                <td><input type="Submit" name="sbt" value="+"></td>
            </tr>
            <tr>
                <td><input type="Submit" name="sbt" value="-"></td>
            </tr>
            <tr>
                <td><input type="Submit" name="sbt" value="*"></td>
            </tr>
            <tr>
                <td><input type="Submit" name="sbt" value="/"></td>
            </tr>
        </table>
    </form>
</body>
</html>