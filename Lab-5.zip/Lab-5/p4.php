<!-- Create a page signin.php , which takes the username, age ,city from user on click of
submit button set the cookies values for each and display values on next page
view.php
 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sign in</title>
    <style>
    input {
        width: 100%;
    }
    </style>
</head>
<body>
    <form method="POST" name="frm" action="./view.php">
        <table>
            <tr>
                <th>Sign in</th>
            </tr>
            <tr>
                <td><input type="text" placeholder="Enter user name" name="uname" required></td>
            </tr>
            <tr>
                <td><input type="number" placeholder="Enter age" name="age" max="100" min="0" required></td>
            </tr>
            <tr>
                <td><input type="text" placeholder="Enter city" name="city" required></td>
            </tr>
            <tr>
                <td><input type="Submit" name="sbt" value="Submit"></td>
            </tr>
        </table>
    </form>
</body>
</html>