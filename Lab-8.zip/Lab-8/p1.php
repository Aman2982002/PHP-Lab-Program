<!-- Create a class Course having property coursename, no_of_year with a constructor, and
display() method for the display course information. Create a class named Student which
inherits a Course having stud_id, stud_name, array of marks(3 subject). Class contains
the constructor and is calling the parent constructor. Class contains method caltotal()
which returns the total of 3 subject marks. It contains display method which shows all
the information about the students: Name,id,marks,total,course name,no_of_year -->
<?php
    class Course{
        public $coursename;
        public $no_of_year;
        function __construct($coursename,$no_of_year)
        {
            $this->coursename = $coursename;
            $this->no_of_year = $no_of_year;
        }
        function display()
        {
            echo "Name of Course is: $this->coursename <br>";
            echo "Total duration of course is $this->no_of_year years <br>";
        }
    }
    class Student extends Course
    {
            public $stud_id;
            public $stud_name;
            public $marks;
            function __construct($stud_id,$stud_name,$marks,$coursename,$no_of_year)
            {
                parent::__construct($coursename,$no_of_year);
                $this->stud_id = $stud_id;
                $this->stud_name = $stud_name;
                $this->marks = $marks;   
            }
            function calTotal()
            {
                return array_sum($this->marks);
            }
            function display()
            {
                echo "ID of Student is: $this->stud_id  <br>";
                echo "Name of Student is: $this->stud_name <br>";
                echo "Marks of Student are: ".implode(', ',$this->marks)."<br>";
                parent::display();
            }
    }
    $S = new Student(23,'Aman',[70,70,70],'MCA',2);
    $S->display();
?>