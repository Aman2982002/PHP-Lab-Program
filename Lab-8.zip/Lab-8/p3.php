<!-- Create an abstract class Employee having a constructor for setting name, year of joining,
date of birth and department of employee. Create an appropriate method to display the
details of the Employee in well designed HTML format. Create an abstract method
calculate_salary() in Employee class.
a. Create a class Manager inherits the Employee class. It should include properties
like basic salary, DA ,tax amount, HRA etc. property. Create the constructor for
setting the values.
Implement the calculate_salary() (basic+DA+HRA – tax amount).
b. Create a class worker which inherits the Employee class. Create a constructor
which sets the property wages per hour,worked hour.
Implement calsal() method (wages per hour*worked hour) .
c. Create appropriate methods in each class to display the well formatted details in
HTML.
d. Write a php program which create multiple object of Manager and Worker class,
and display the name, designation and salary of each -->
<?php
abstract class Employee
{
    protected $name;
    protected $yoj;
    protected $dob;
    protected $depart;
    public function __construct($name,$yoj,$dob,$depart)
    {
        $this->name = $name;
        $this->yoj = $yoj;
        $this->dob = $dob;
        $this->depart = $depart;
    }
    public abstract function calculate_salary();
    public abstract function DisplayDetails();
}
class Manager extends Employee
{
    public $basicsalary;
    public $DA;
    public $taxAmount;
    public $HRA;
    function __construct($name,$yoj,$dob,$depart,$basicsalary,$DA,$taxAmount,$HRA)
    {
        parent::__construct($name,$yoj,$dob,$depart);
        $this->basicsalary = $basicsalary;
        $this->DA = $DA;
        $this->taxAmount = $taxAmount;
        $this->HRA = $HRA;
    }
    public function calculate_salary()
    {
        return ($this->basicsalary+$this->DA+$this->HRA-$this->taxAmount);
    }
    public function DisplayDetails()
    {
        echo "<h2>Manager Details</h2>";
        echo "<p>Name: $this->name </p>";
        echo "<p>Year of Joining: $this->yoj </p>";
        echo "<p>Date of Birth:  $this->dob </p>";
        echo "<p>Department: $this->depart </p>";
        echo "<p>Designation: Manager</p>";
        echo "<p>Salary: ".$this->calculate_salary() ."</p>";
    }
}
class Worker extends Employee
{
    public $workedHours;
    public $wagesPerHour;
    function __construct($name,$yoj,$dob,$depart,$workedHours,$wagesPerHour)
    {
        parent::__construct($name,$yoj,$dob,$depart);
        $this->workedHours = $workedHours;
        $this->wagesPerHour = $wagesPerHour;
    }
    public function calculate_salary()
    {
        return ($this->wagesPerHour*$this->workedHours);
    }
    public function DisplayDetails()
    {
        echo "<h2>Worker Details</h2>";
        echo "<p>Name: $this->name </p>";
        echo "<p>Year of Joining: $this->yoj </p>";
        echo "<p>Date of Birth:  $this->dob </p>";
        echo "<p>Department: $this->depart </p>";
        echo "<p>Designation: Worker</p>";
        echo "<p>Salary:".$this->calculate_salary()." </p>";
    }
}
$manager1 = new Manager('Steave Rogers',2002,'1956-08-05','sales',50000,2000,5500,1000);
$manager2 = new Manager('Tony Stark',2004,'1987-10-17','Admin',120000,5000,4500,3000);
$worker1 = new Worker('Bruce Banner',2005,'1985-01-25','sales',200,200);
$worker2 = new Worker('Clint Barton',2021,'1990-05-25','Admin',150,150);
$manager1->DisplayDetails();
$manager2->DisplayDetails();
$worker1->DisplayDetails();
$worker2->DisplayDetails();
?>