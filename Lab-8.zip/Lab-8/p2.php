<!-- Create a class named shape having a method area() which calculates the area of the
shape and returns the area.
a. Create a class circle which inherits Shape and overrides the area() method and
returns the area of the circle.
b. Create a class square which inherits the Shape class and have an area() method to
return the area of the square.
c. Create a class Rectangle which inherits the Shape class and have an area()
method which returns the area of the Rectangle.
d. Create the object of class shape ,circle,square and rectangle class and display area
of each. [ override the area() method] -->
<?php
    class Shape
    {
        function area()
        {
            echo "<b>AREA : </b><br>";
        }
    }
    class Circle extends Shape
    {
        public $radius;
        function __construct($radius)
        {
            $this->radius = $radius;
        }
        function area()
        {
            $area = 3.14*($this->radius*$this->radius);
            return $area;
        }
    }
    class Square extends Shape
    {
        public $length;
        function __construct($length)
        {
            $this->length = $length;
        }
        function area()
        {
            $area = $this->length*$this->length;
            return $area;
        }
    }
    class Rectangle extends Shape
    {
        public $length,$width;
        function __construct($length,$width)
        {
            $this->length = $length;
            $this->width = $width;
        }
        function area()
        {
            $area = $this->length*$this->width;
            return $area;
        }
    }
    $sh = new Shape();
    $area = $sh->area();
    print($area);
    $cir = new Circle(50);
    $area = $cir->area();
    print("Area of Circle is: $area <br>");
    $sqr = new Square(40);
    $area = $sqr->area();
    print("Area of Square is: $area <br>");
    $rect = new Rectangle(20,25);
    $area = $rect->area();
    print("Area of Rectangle  is: $area <br>");
?>