<!--  Create a php script which checks whether the number is palindrome or not. E.d 121 is a
palindrome number.
 -->
<?php
function isPalindrome($number) {
    $numberString = strval($number);
    $reverseString = strrev($numberString);

    return $numberString === $reverseString;
}
$number1 = 121;
echo "$number1 is " . (isPalindrome($number1) ? "a palindrome" : "not a palindrome");
?>
