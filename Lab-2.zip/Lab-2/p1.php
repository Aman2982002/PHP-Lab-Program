<!-- Create two variables of integer type and display the value of the variables -->
<?php
    $num1 = 10;
    $num2 = 20;

    echo "Number:$num1";
    echo "<br>";
    echo "Number:$num2";
?>