<!--  Create a php script which prints the first ten odd numbers.
 -->
<?php
for ($i = 1; $i <= 19; $i += 2) {
    echo $i . " ";
}
?>
