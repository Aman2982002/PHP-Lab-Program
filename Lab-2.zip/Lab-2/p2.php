<!--  Create a php script which declares all the scalar data types of variables and displays the
value . -->
<?php

$iVar = 14;
$fVar = 3.14;
$sVar = "Hello world!";
$bVar = true;

echo "Integer Variable:$iVar";
echo "<br>";
echo "Float Variable:$fVar";
echo "<br>";
echo "String Variable:$sVar";
echo "<br>";
echo "Boolean Variable:$bVar";
?>