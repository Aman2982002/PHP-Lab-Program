<!-- Create a php script which performs string operations -->
<?php
    $str1 = "Hello";
    $str2 = "DDU";

    $con = $str1.$str2;

    $str1 .= $str2;

    echo "<b>Concatenation::$con<b>";
    echo "<br>";
    echo "<b>Concatenation & Assighment::$str1<b>";

    

?>