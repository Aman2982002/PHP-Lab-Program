<!-- Develop a PHP form to get students marks of 5 subjects and generate results. Take the following
inputs: Exam No, Course (Drop Down), Student photo and Semester. The photo should not be
greater than 25 kb in size and must be in JPEG format. Check necessary validation and provide
the option to upload the photograph on click on upload button. Display the rest of the detail on
the browser on click on submit button.
 -->
<!DOCTYPE html>
<html>
<head>
    <title>Student Result Form</title>
</head>
<body>
    <?php
    $examNo = $course = $semester = "";
    $marks = array();
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $examNo = test_input($_POST["examNo"]);
        $course = test_input($_POST["course"]);
        $semester = test_input($_POST["semester"]);
        if (empty($examNo) || empty($course) || empty($semester)) {
            echo "All fields are required.";
        } else {
            for ($i = 1; $i <= 5; $i++) {
                if (isset($_POST["mark$i"])) {
                    $marks[$i] = test_input($_POST["mark$i"]);
                }
            }
            if ($_FILES["photo"]["size"] > 0) {
                $allowedTypes = array("image/jpeg");
                $maxFileSize = 25 * 1024;
                if (in_array($_FILES["photo"]["type"], $allowedTypes) && $_FILES["photo"]["size"] <= $maxFileSize) {
                    $photoPath = "uploads/" . $_FILES["photo"]["name"];
                    move_uploaded_file($_FILES["photo"]["tmp_name"], $photoPath);
                } else {
                    echo "Invalid photo format or size.";
                }
            }
        }
    }
    function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    ?>
    <h2>Student Result Form</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
        Exam No: <input type="text" name="examNo"><br><br>
        Course:
        <select name="course">
            <option value="Mca">MCA</option>
            <option value="Mscit">MscIT</option>
            <option value="CE">CE</option>
            <option value="CS">CS</option>
        </select><br><br>
        Semester: <input type="text" name="semester"><br><br>
        <?php
        for ($i = 1; $i <= 5; $i++) {
            echo "Subject $i Mark: <input type='text' name='mark$i'><br><br>";
        }
        ?>
        Photo: <input type="file" name="photo"><br><br>
        <input type="submit" name="submit" value="Submit">
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && count($marks) == 5) {
        echo "<h2>Student Result</h2>";
        echo "Exam No: $examNo<br>";
        echo "Course: $course<br>";
        echo "Semester: $semester<br>";
        echo "Marks:<br>";
        foreach ($marks as $subject => $mark) {
            echo "Subject $subject: $mark<br>";
        }
        if (isset($photoPath)) {
            echo "Photo: <img src='$photoPath' alt='Student Photo' width='150'><br>";
        }
    }
    ?>
</body>
</html>