<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: 4.html');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product = $_POST['product'];
    $quantity = $_POST['quantity'];

    $_SESSION['cart'][] = ['product' => $product, 'quantity' => $quantity];
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Cart</title>
</head>

<body>
    <h2>Your Cart</h2>
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
        </tr>
        <?php foreach ($_SESSION['cart'] as $item): ?>
            <tr>
                <td>
                    <?php echo $item['product']; ?>
                </td>
                <td>
                    <?php echo $item['quantity']; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <form action="purchase.php" method="post">
        <input type="submit" value="Buy">
    </form>
    <a href="product.php">Continue Shopping</a>
</body>

</html>