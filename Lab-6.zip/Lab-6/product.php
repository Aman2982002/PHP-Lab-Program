<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: 4.html');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
    <h3>Select a product:</h3>
    <form action="cart.php" method="post">
        <label>Product:</label>
        <select name="product">
            <option value="Bounvita">Bounvita</option>
            <option value="Milk">Milk</option>
            <option value="Shampoo">Shampoo</option>
            <option value="Kurkure">Kurkure</option>
            <option value="Hide&Seek">Hide&Seek</option>
            <option value="KitKat">KitKat</option>

        </select><br>
        <label>Quantity:</label>
        <input type="number" name="quantity" value="1" min="1"><br>
        <input type="submit" value="Add to Cart">
    </form>
    <a href="logout.php">Logout</a>
</body>
</html>
