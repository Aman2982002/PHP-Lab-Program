<!-- Create php code which do following task
Signup.php : take username and password from user and select hobbies(from checkbox) & store
information as session variable. Store password in encrypted format using md5 encryption.
Viewhobbie.php : if session variable username not set display “login required” message else
display the hobbies of respective user in a well designed page.
Singout.php : clear the session variables.
 -->
<?php
session_start();
if (isset($_POST['submit'])) {
    $_SESSION['username'] = $_POST['username'];
    $_SESSION['password'] = $_POST['password'];
    $_SESSION['hobbies'] = $_POST['hobbies'];
    header('Location: Viewhobbie.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
</head>
<body>
    <form method="post">
        <label>Username:</label>
        <input type="text" name="username"><br><br>
        <label>Password:</label>
        <input type="password" name="password"><br><br>
        <label>Hobbies:</label><br>
        <input type="checkbox" name="hobbies[]" value="Reading">
        <label> Reading</label><br>
        <input type="checkbox" name="hobbies[]" value="Sports">
        <label> Sports</label><br>
        <input type="checkbox" name="hobbies[]" value="Music">
        <label> Music</label><br><br>
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
