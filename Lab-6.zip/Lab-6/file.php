<?php
if (isset($_POST['write'])) {
    $filename = $_POST['filename'];
    $content = $_POST['content'];
    $file = fopen($filename, "a");
    fwrite($file, $content);
    fclose($file);
} elseif (isset($_POST['read'])) {
    $filename = $_POST['filename'];
    if (file_exists($filename)) {
        $file = fopen($filename, "r");
        echo fread($file, filesize($filename));
        fclose($file);
    } else {
        echo "File does not exist.";
    }
}
?>