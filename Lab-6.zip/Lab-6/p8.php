<?php
if(isset($_POST['submit'])){
if ($_POST['number'] < 0) {
trigger_error("The number entered is negative",
E_USER_WARNING);
}
}
?>