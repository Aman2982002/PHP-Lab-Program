<?php
session_start();
echo "Name : " . $_SESSION['name'] . "<br>";
echo "Sub1 : " . $_SESSION['subject1'] . "<br>";
echo "Sub2 : " . $_SESSION['subject2'] . "<br>";
echo "Sub3 : " . $_SESSION['subject3'] . "<br>";
?>