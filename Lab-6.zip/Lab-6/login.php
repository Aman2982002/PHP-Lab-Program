<?php
session_start();

$users = [
    'user1' => 'password1',
    'user2' => 'password2'
];

if (isset($_POST['Login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isset($users[$username]) && $users[$username] === $password) {
        $_SESSION['username'] = $username;
        header('Location: product.php');
        exit;
    } else {
        echo "Invalid username or password.";
    }
}
?>
