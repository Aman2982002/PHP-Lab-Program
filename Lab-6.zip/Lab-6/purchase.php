<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: 4.html');
    exit;
}
unset($_SESSION['cart']);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Purchase Complete</title>
</head>

<body>
    <h2>Thank you for your purchase!</h2>
    <a href="product.php">Back to Products</a>
</body>

</html>