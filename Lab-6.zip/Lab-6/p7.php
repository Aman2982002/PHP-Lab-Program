<?php
function customErrorHandler($num1, $num2) {
    if (!is_numeric($num1) || !is_numeric($num2)) {
        trigger_error("Both parameters must be numbers.", E_USER_ERROR);
    }
    
    if ($num1 < $num2) {
        trigger_error("Warning: Parameter 1 is less than Parameter 2.", E_USER_WARNING);
    }
    else{
        echo "ok";
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $num1 = $_POST["num1"];
    $num2 = $_POST["num2"];

    customErrorHandler($num1, $num2);
}
?>
