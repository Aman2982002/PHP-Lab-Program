<?php
session_start();
if (!isset($_SESSION['username'])){
    echo "Login required.";
}
else
{
    echo $_SESSION['username']  . "<br>";
    foreach ($_SESSION['hobbies'] as $hobby){
        echo $hobby . "<br>";
    }   
}
?>