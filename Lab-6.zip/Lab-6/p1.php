<!--  Create a php page which takes the student’s name and marks of three subjects from the user.
Manage all information via session and display all information on the next page.
 -->
<?php
session_start();
if (isset($_POST['submit'])) {
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['subject1'] = $_POST['subject1'];
    $_SESSION['subject2'] = $_POST['subject2'];
    $_SESSION['subject3'] = $_POST['subject3'];
    header('Location: p1_display.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Information</title>
</head>
<body>
    <form method="post">
        <label>Name:</label>
        <input type="text" id="name" name="name"><br><br>
        <label>Subject 1:</label>
        <input type="text" name="subject1"><br><br>
        <label>Subject 2:</label>
        <input type="text" name="subject2"><br><br>
        <label>Subject 3:</label>
        <input type="text" name="subject3"><br><br>
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>