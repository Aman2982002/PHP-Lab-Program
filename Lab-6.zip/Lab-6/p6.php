<!-- Create a php script to demonstrate different types of errors.(Notice, warning, error -->
<?php
echo $undefinedVariable;
$file = "non_existent_file.txt";
$fileHandle = fopen($file, "r");
function divideByZero() {
    $result = 10 / 0;
    return $result;
}
divideByZero();
?>
