<!-- Create a class vehicle having properties prodyear,company name and a protected
method for setting and getting values. Create subclass TwoWheeler inherits from
vehicle. Properties are nameofvehicle, color. It contains methods setvalues() and
getvalues() which set the values of all properties and display it respectively. Create a
subclass FourWheeler inherits from vehicle class. Properties are vehiclename, color,
price, tolltaxrate . It contains constructor which set all the properties. Display()
method for displaying the details. Create an object of TwoWheeler and FourWheeler
and display all the details for both the objects. -->

<?php
class Vehicle {
    protected $prodyear;
    protected $company_name;

    protected function setValues($prodyear, $company_name) {
        $this->prodyear = $prodyear;
        $this->company_name = $company_name;
    }

    protected function getValues() {
        return [$this->prodyear, $this->company_name];
    }
}

class TwoWheeler extends Vehicle {
    protected $name_of_vehicle;
    protected $color;

    public function setValues($prodyear, $company_name) {
        parent::setValues($prodyear, $company_name);
    }

    public function setAdditionalValues($name_of_vehicle, $color) {
        $this->name_of_vehicle = $name_of_vehicle;
        $this->color = $color;
    }

    public function getValues() {
        [$prodyear, $company_name] = parent::getValues();
        return [$prodyear, $company_name, $this->name_of_vehicle, $this->color];
    }
}

class FourWheeler extends Vehicle {
    protected $vehiclename;
    protected $color;
    protected $price;
    protected $tolltaxrate;

    public function __construct($prodyear, $company_name, $vehiclename, $color, $price, $tolltaxrate) {
        parent::setValues($prodyear, $company_name);
        $this->vehiclename = $vehiclename;
        $this->color = $color;
        $this->price = $price;
        $this->tolltaxrate = $tolltaxrate;
    }

    public function display() {
        [$prodyear, $company_name] = parent::getValues();
        echo "Vehicle Information:\n";
        echo "Production Year: $prodyear\n";
        echo "Company Name: $company_name\n";
        echo "Vehicle Name: $this->vehiclename\n";
        echo "Color: $this->color\n";
        echo "Price: $this->price\n";
        echo "Toll Tax Rate: $this->tolltaxrate\n";
    }
}

// Create instances of TwoWheeler and FourWheeler
$twoWheeler = new TwoWheeler();
$twoWheeler->setValues(2023, "Honda");
$twoWheeler->setAdditionalValues("Activa", "Blue");

$fourWheeler = new FourWheeler(2023, "Toyota", "Camry", "Silver", 35000, 0.05);

// Display details
echo "Two-Wheeler Details:\n";
[$twoWheelerProdYear, $twoWheelerCompany, $twoWheelerName, $twoWheelerColor] = $twoWheeler->getValues();
echo "Production Year: $twoWheelerProdYear\n";
echo "Company Name: $twoWheelerCompany\n";
echo "Name of Vehicle: $twoWheelerName\n";
echo "Color: $twoWheelerColor\n";

echo "\nFour-Wheeler Details:\n";
$fourWheeler->display();
?>
