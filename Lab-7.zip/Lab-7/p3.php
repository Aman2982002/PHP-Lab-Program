<!-- Create a class course having properties coursename,noofyear. Create setter and
getter public methods for each property. Create a student class which inherits the
course class. Student class should have name, passout year, resultclass properties .
Student class contain public method setvalue() which set all the properties value.
And display() which display all the values. Create four different object of student
class and display details of each object.
 -->

<!DOCTYPE html>
<html>
<head>
    <title>Student Details</title>
</head>
<body>
    <h1>Student Details</h1>
    <?php
    class Course {
        private $courseName;
        private $noOfYears;
        public function setCourseName($name) {
            $this->courseName = $name;
        }
        public function getCourseName() {
            return $this->courseName;
        }
        public function setNoOfYears($years) {
            $this->noOfYears = $years;
        }
        public function getNoOfYears() {
            return $this->noOfYears;
        }
    }
    class Student extends Course {
        private $name;
        private $passoutYear;
        private $resultClass;
        public function setValue($courseName, $noOfYears, $name, $passoutYear, $resultClass) {
            $this->setCourseName($courseName);
            $this->setNoOfYears($noOfYears);
            $this->name = $name;
            $this->passoutYear = $passoutYear;
            $this->resultClass = $resultClass;
        }
        public function display() {
            echo "<h2>Student Details</h2>";
            echo "Course Name: " . $this->getCourseName() . "<br>";
            echo "Number of Years: " . $this->getNoOfYears() . "<br>";
            echo "Student Name: " . $this->name . "<br>";
            echo "Passout Year: " . $this->passoutYear . "<br>";
            echo "Result Class: " . $this->resultClass . "<br><br>";
        }
    }
    $student1 = new Student();
    $student1->setValue("MCA", 2, "Aman", 2024, "First Class");
    $student2 = new Student();
    $student2->setValue("MCA", 2, "Rahul", 2022, "Distinction");
    $student3 = new Student();
    $student3->setValue("Btech", 4, "Karan", 2024, "Second Class");
    $student4 = new Student();
    $student4->setValue("Mtech", 4, "Jaivin", 2023, "Pass");
    echo "<h2>Student 1 Details</h2>";
    $student1->display();
    echo "<h2>Student 2 Details</h2>";
    $student2->display();
    echo "<h2>Student 3 Details</h2>";
    $student3->display();
    echo "<h2>Student 4 Details</h2>";
    $student4->display();
    ?>
</body>
</html>