<!--  Create a PHP script that displays “Hello World” on the web page -->
<?php
    echo "<h1>";
    echo "Hello, World!";
    echo "</h1>";
?>