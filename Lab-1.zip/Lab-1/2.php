<!-- Create PHP script which prints Name , Roll Number & sem 2 SPI on the web page.
 -->
<html>
    <head></head>
    <body>
        <?php
            echo "<h1>";
            echo "Name : Aman Khatri <br>";
            echo "RollNo : MA023 <br>";
            echo "Sem 2 SPI : 7.61<br>";
            echo "</h1>";
        ?>
    </body>
</html>