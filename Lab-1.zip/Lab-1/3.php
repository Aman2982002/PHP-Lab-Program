<?php
    echo "<h1>";
    echo "Name : Aman<br>";
    echo "Roll No. : 1<br>";
    echo "SPI : 7<br>";
    echo "</h1>";
?>