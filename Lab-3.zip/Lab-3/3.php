<!-- Write a php script which having multidimensional array for storing information l -->
<?php
$students = array(
    array(
        'Item' => 'Item 1',
        'price' => 1500,
        'quentity' => 400
    ),
    array(
        'Item' => 'Item 2',
        'price' => 2500,
        'quentity' => 200
    ),
    array(
        'Item' => 'Item 3',
        'price' => 3500,
        'quentity' => 500
    ),
    array(
        'Item' => 'Item 4',
        'price' => 3000,
        'quentity' => 3000
    ),
    array(
        'Item' => 'Item 5',
        'price' => 200,
        'quentity' => 5000
    ),
    // Add more students here...
);
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>Item</th>
            <th>price</th>
            <th>quentity</th>
        </tr>
        <?php foreach ($students as $student) { ?>
            <tr>
                <td><?php echo $student['Item']; ?></td>
                <td><?php echo $student['price']; ?></td>
                <td><?php echo $student['quentity']; ?></td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>
