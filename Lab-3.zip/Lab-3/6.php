<!--  Write a script which creates an array called marks , containing student name as key and
mark as value. (e.g “Pratik”=> 34 ,”reema”= 36) .
➔ Display the array according to marks in ascending order.
➔ Display the array according to the name in descending order -->
<?php
$marks = array(
    "A" => 50,
    "B" => 46,
    "C" => 52,
    "D" => 19,
    "E" => 90
);

asort($marks);

echo "Array sorted by marks in ascending order:<br>";
foreach ($marks as $name => $mark) {
    echo "$name: $mark<br>";
}

echo "<br>";

krsort($marks);
echo "Array sorted by names in descending order:<br>";
foreach ($marks as $name => $mark) {
    echo "$name: $mark<br>";
}
?>
