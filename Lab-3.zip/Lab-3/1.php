<!-- Write a php script to create an associative array with 5 different elements and display its
key and value. -->
<?php
$a = array(
    "name" => "Aman Khatri",
    "age" => 21,
    "city" => "Patan",
    "email" => "amankhatri@gmail.com",
    "state" => "Gujarat"
);

foreach ($a as $key => $value) {
    echo " $key :  $value <br>";
}
?>
