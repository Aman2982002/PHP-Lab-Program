<!-- Write a php script which creates an array[3][2] matrix and displays the matrix. -->

<?php
// Create a 3x2 matrix as a multidimensional array
$matrix = array(
    array(1, 2),
    array(3, 4),
    array(5, 6)
);

// Display the matrix
echo "Matrix:<br>";
for ($row = 0; $row < 3; $row++) {
    for ($col = 0; $col < 2; $col++) {
        echo $matrix[$row][$col] . " ";
    }
    echo "<br>";
}
?>
